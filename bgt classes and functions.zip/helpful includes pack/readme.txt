helpful includes pack,. by: harry production!

description:
this pack contain helpful things and shorten words during making your game, with the bgt language If you are making on. If you are making your games on the focus of bgt, and If you want some functions to be quicker or shorten? this includes pack will enough for you! these functions have made easier and shorten to be used in the somewhere you want to use. every function has it's own descriptions, and some functions can have an example. harry production team has published this pack for those who want to be shorten words, or for those who want to use the easyest functions. although this pack contain lots of functions, however some of things are left to be added. though the tasks still left to be added, you can now do common tasks as per your requirement with the below functions. easy, shorten, freely and useful for all of you!
we hope you enjoy this pack, and make sure to report any bugs or any rong things to our team If you found any.
If you think that the function should be added or If there's something to change, please contact us!
email: 
yarzarminkhant39@gmail.com
telegram:
@harrymktbot



bool kp(int key)
a bool function, true or false. this function is for those who do not want to type the long characters. this returns as the key_pressed. true means the key is pressed, on the other hand, false means the key is not pressed.
there is 1 parameter.
int key: an int function which is use for which key to be pressed. for the keys list, please check out with the following: open the start menu, then, find the bgt folder, and expand it. and then, press the help button and see in the keyboard keys reference.

example: 
if(kp(KEY_A))
{
alert("nice","the key is pressed");
}



bool kd(int key)
just the same with the above function, this is just for key down.
int key: an int function which is use for which key to be helled down.

example: 
if(kd(KEY_A))
{
alert("nice","the key is helled down");
}



bool alshdown()
this function is returns that the alt and the shift is down or not.
parameter true means If will hell down, false means it will not, or be error.
If this was true, the key will be hell down, and it will include like this. alt+shift+a, like just example.

example: 
if(alshdown() and kp(KEY_A))
{
alert("nice","it was, alt+shift+a");
}



bool alshdownpress(int key)
a bool function, true or false, which is the key alt and the shift down, and it's press the key.
int key: an int function which is use for which key to be pressed.
see example below for how it works.

example: 
if(alshdownpress(KEY_RETURN))
{
alert("nice","alt+shift+enter has been pressed);
}



bool altcodownpress(int key)
a bool function, true or false, which is the control and the alt key being hell down, and press the key that you specified.
int key: an int function which is use for which key to be pressed.

bool coshdown()
a bool function, true or false. If this is true, the control and the shift key will be helled down. on the other hand, false means the control and the shift keys will not be helled down.


bool altcodown()
a bool function, true or false. true means the control and the alt key being hell down, and the false means It won't.


bool coshdownpress(int key)
a bool function, true or false. If this is true, the control and the shift key will be helled down and pressed the key that you specified. on the other hand, false means the control and the shift keys will not be helled down and will not be pressed the key.
int key: an int function which is use for which key to be pressed.

string hts(string n)
a string function which you can convert to hex to string.
string n: the text to be converted.

string sth(string n)
a string function which you can convert to the hex from a string.
string n: the text to be converted.


bool gmw(string project_name,string version,string author)
this function allows you to see the game window into your project, easily and shortly.
string project_name: the name of the project you wish to be shown.
string version: the version of the project that your project is in.
string author: the name of the development team that you are currently authorized.

example:
gmw("file info checker","1.5","harry production");
then output should be file info checker version 1.5 by harry production
*end example

void newfolder(string n)
this function allows you to create the directories with a lot easyer.
string n: the directory to be created.

void delfolder(string name,bool confirmation=false)
this function allows you to delete the directories in an instant. also you can decide whether you want to delete or not by making confirmation true.
string name: a specify folder name to delete.
bool confirmation, true or false: this is to decide whether asking to deleting or not. leave this function true, If you want to turn the asking on.


void messagebox(string title,string message)
this function allows you to display a message with the title.


bool is_letnums(string t)
this function returns true or false, whether the text contain letters and numbers, or not. If the text contain other character such as semicolon, colon, or other simbles, it will return false. because If you will use the default string, you will need type the long characters.

bool is_only_letters(string t)
this function returns true or false, whether the text is only letters. this function is the same with the above function, not to type long character.

ntw
convert the given numbers to the exact words which you given the numbers.
string ntw(double numbers,bool include_and=false)

parameters:
numbers
the numbers to convert
include_and
a bool function which specify whether and should be included or not in between number spokens. for example, 5 hundred and ninety nine If it's true.

return value:
The word representation of the number on success, or an empty string on failure.

remarks:
This function only works with numbers (positive or negative), without decimals. If the supplied number contains decimals, these will simply be removed without rounding.
If the number is lower than -999999999 (minus nine hundred ninety nine million nine hundred ninety nine thousand nine hundred ninety nine) or greater than 999999999 (nine hundred ninety nine million nine hundred ninety nine thousand nine hundred ninety nine), the function will fail.
This function is very useful when you wish to have a number spoken by using concatenated sound files, for instance. Simply split the words up into an array with the string_split function, and then loop through the resulting array and play an appropriate sound file for each word.

get_name_s_or_others
this function simply returns value which for the last of the name, such as es, ies, or s.

string get_name_s_or_others(string name)
parameters:
name
the name you wish to check for.

return value:
receives anything such as s, es, or ies on success, an empty string on failure.

remarks:
this function simply returns value which for the last of the name, such as es, ies, or s.

get_a_or_an
this function simply returns the value of the name for example, a forest, an orange, etc.

string get_a_or_an(string name)
parameters:
name
the name you wish to check for.

return value:
receives a or an on success, an empty string on failure.

remarks:
this function simply returns the value of the name for example, a forest, an orange, etc.
it returns between (a) or (an).
for example: "+get_a_or_an("orange")+" orange. //output should be an orange.

rdm

returns a random number and round If available.
double rdm(double minimum,double maximum,bool rounded=false,double number_of_rounding=0)
parameters:
minimum
the minimum number to get random number from.
maximum
the maximum number to get random to.
rounded
a boolean value specifying whether, this random numbers should be rounded or not.
number_of_rounding
a specify round number to be rounded. this will only be rounded If the bool is true

return value:
the random number.

remarks:
this helps you to get a specify minimum and maximum numbers randomly, and you can choose whether, the numbers should be rounded or not, and If roundable, you can also choose the numbers to be rounded. the possible values are from between -999999999, and 999999999, as this bgt's random only supports the range of possible values even If this is being a double functioncall, since this random function from which bgt default is being long functioncall.

get_modified_time

returns the modified time such as last updated or whatever with a specify year,month,day,hour,minute,or even seconds.
string get_modified_time(double y,double m,double d,double h,double mn,double s)
parameters:
y
the year you wish to check for.
m
the month you wish to check for, from 1 to 12.
d
the day you wish to check for, from 1 to 31.
h
the hour to check for, from 0 to 23.
mn
the minute you wish to check for, from 0 to 59.
s
the second you wish to check for, from 0 to 59.

return value:
a string containing the date on success, an empty string on failure.

remarks:
this function helps you to get the modified time of the year, month, day, hour, minute, and second. for example: 1 year ago. 5 months ago. etc.

example:
none

get_sayable_time

this function returns the time, for instance.
string get_sayable_time(double a,double b,double c,double d=-1,double e=-1,double f=-1)
parameters:
a
the year you wish to check for.
b
the month you wish to check for, from 1 to 12.
c
the day you wish to check for, from 1 to 31.
d
the hour to check for, from 0 to 23 (optional).
e
the minute you wish to check for, from 0 to 59 (optional).
f
the second you wish to check for, from 0 to 59 (optional).

return value:
a string containing a converted date on success, an empty string on failure.

remarks:
this function returns the date of year,month,day, for instance. some optional parameters are hour,minute,and second. for example, lets say year is 2022,month is 8,day is 10. the output should be Wednesday, August 10, 2022.

example:
none


convert_to_list

this function converts an array to a listed string, for instance.

string convert_to_list(array)
parameters:
array
an array which you want to be converted. currently supports string, int, uint, and double.

return value:
a string containing the converted list on success, or an empty string on failure.

remarks:
this function returns into a converted list of an array, for instance. this function is useful in your program just in case, for example. lets say your game has admins, but you want to convert in a list to show throughout the game who type /admins.

example:
string[] admins={"yes","no","ok","cancel"};
alert("hi","the converted list contains: "+convert_to_list(admins)+"!"); //output should be (yes, no, ok, and cancel).

webload

this function loads a given URL.
bool webload(string web)
parameters:
web
the web that should be loaded.

return value:
true on If the specify web that loaded successfully, false otherwise.

remarks:
this function runs a given web URL at your default browser. however, the specify web name must be a URL, will be failed and returned false otherwise.
you can check whether the specify web name is an URL or not using is_link function.

convert_month_name

this function converts a given value to the month name.
string convert_month_name(double value)
parameters:
value
a double value specifying the month, from 1 to 12

return value:
the converted string of the month name on success, or an empty string on failure.

remarks:
this function converts a given value of the month into the sayable month name, for example, january=1.

convert_month_number

this function converts a month name string into the value of the month.
double convert_month_number(string monthname)
parameters:
monthname
a string specifying the name of the month.

return value:
returns a converted value of the month name on success. otherwise, -1is return.

remarks:
this function converts the month name into the value of the month. for example, 1=january, 2=febuary etc. when converting the month name, every first character of the month name must be a capital letter.

convert_weekday_name

this function converts a given value into the weekday name.
string convert_weekday_name(double value)
parameters:
value
the weekday you wish to convert(from 1 to 7)

return value:
the converted weekday name string on success, an empty string on failure.

remarks:
this function converts a given value to the name of the weekday. for example, 1=sunday or 2=monday.

get_current_directory
This function returns the full directory of the script currently running, whether it be a bgt script or an executable.

file_put_contents
this function allows you to put the text into a file with the specify filename within a specify mode, I've declared above. This is similar to the php equivalent, where you need no file objects, you just need some strings and a flag.
This function has three peramitors.
the first peramitor is the filename to use.
The second peramitor is the contents to put to the file.
The third peramitor is an uint8 number, for the mode.
The modes were up there, but here they are again.
FILE_WRITE
deletes all contents before writing your string.
FILE_APPEND
appends your string to the end of the file.

file_get_contents
Again, like the php equivalent.
this function allows you to get the text of the filename that you specified. 
this function has one peramitor, the filename to get the contents from.

dict_to_ini
converts a dictionary to the ini standard, key=value, and writes it to a file.
it is a boolean, so you can see if it worked, again like phillip's functions.
the first peramitor is the handle to a dictionary you would like converted.
the second is a string specifying the filename.
I know this might be useless, since you have serialize, but I just put it here in case somebody wanted ini files for stuff.

ini_to_dict
this function is a bool! Be careful!
Unlike deserialize, this function does not return a dictionary handle.
Instead, it writes directly to an &out dictionary.
The boolean is so you can see if the opening worked.
the first peramitor is the string of the ini file you wish to read.
the second peramitor is a handle to a dictionary to write to, so you would call something like this.
dictionary test;
bool worked=ini_to_dict("test.ini",test);
if(worked==false)
{
alert("Error","The file test.ini doesn't exist.");
}
and the dictionary would be filled.
This function will only convert key=value, it will not support sectioned ini files such as those seen in ISS files.
However, it does support semicolon line commenting.
This function is the inverse of dict_to_ini, and so should only be used when using that function to make the original file, unless you know that it is safe for parsing. Anything messed up may result in very strange output in the dictionary.

average
finds the average out of an array of doubles.
the first peramitor is the array of doubles to find the average out of.
the second is the amount of rounding to apply, sent to the round function. Default is 2, meaning 2 decimal places.
this returns a double for precise averages. TO get something that is integer compatible, send 0 for the second peramitor.

dget
the following two functions are equal in every way accept they are meant for different types of values.
You know how you have to create a temporary value in order to get something from a dictionary? Not with this function!
This function, dget, will allow you to retrieve values directly to the return.
Because bgt won't allow me to have functions with the same name and peramitors, I thought return type mattered too, declare the function as such.
dget_var
where var is one of the data types it can return, such as dget_double
this function takes two peramitors.
the first is the dictionary to get the value from.
the second is the name of the key the value is linked to.
The return type can either be double or string.

dget_sd
this function will get the value from a dictionary in string format, such as if you loaded it from an ini file, and convert it to double before returning it.
same as dget_double accept it will handle converting string to number

array_add
these next two functions are for adding arrays to other arrays at an index.
string and double
the first peramitor is the array to insert the other array into
the second peramitor is the array to be inserted
the third peramitor is the index of insertion. -1 for end. Note that if you specify an insertion index that is higher than the length of the original array, it will be inserted at the end just like if you used -1.}
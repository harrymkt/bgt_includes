hahaha, welcome back to harry production. in this class, we made window functions useable for you or for have fun.
the function includes alert, show_game_window, and more. in the class, some of them are different.

gwindow() properties:
{
window_title : returns the title of the previous window that was through show() or initialise(). warning! this does not work with default show_game_window function.
}

If the function has one or more same functionality, they will be seperet by 2 verticle bars, that is to say (||) character.


bool show(string t) || bool initialise(string t)
these 2 functions allows you to show the game window. initialise is the same as python hahaha!


bool hide()
this allows you to hide the window.

bool is_focused_window()
this checks whether the game window is currently in focus or not.

string input(string title,string text,string deftext="")
same as the input_box(string,string,(optional)string)

bool admin()
returns true If in admin mode, false otherwise.

bool print(string title,string t) || 
this prints the title and a text.

void message(string title,string message)
this prints as the above function, but use with library.

void sleep(double ms)
waits for a specified millisecond. this might as the python lol!

double rand(double from,double to)
this function generates the random number from a starting range to the end range.
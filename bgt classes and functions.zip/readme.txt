this is all the bgt classes and functions which made, edited, or modified by harry production team. while using all of these, you can report any of the bugs or rong functions to the team If you found any.
our team's telegram account is:
@harrymktbot
or go through this link:
https://t.me/harrymktbot

email:
yarzarminkhant39@gmail.com

please note: all of these might update from time to time when we have a new idea with a new script.
while using all of these classes and functions, you're agreeing to follow the rules.
1. make sure not to decide to remove the credits or other files partof in these classes and functions. If we found you that you are doing so, we may not give you access to use these classes and functions anymore. If you do not accept this rule, do not use these classes and functions into your project.
2. this is not allowed, repeat, this is not allowed to remove credits or using credit yourself, this is not allowed under any circumstances. also do not use these classes and functions If you do not accept this rule.

each class of function has a folder, inside the folder you can found the code for it, and readme in some classes and functions. also some scripts contain examples and helps inside the codes, while some scripts are not.
all of these scripts might not be the best things, however I think you might need for your games sometimes.
this class(announcement class) allows you to add recent important announcements into your game, with a folder called announcements.

functions:
these functions sorted by function titles, left paren, subtitles, short description, parameters, return value, remarks, example, and right paren. If the function has more than 1 subtitles, they may sorted by 2 blank lines between previous and next function-subtitle.

announcement object properties
(
(pyear) (pmonth) (pday) (phour) (pminute) (psecond)
the published date of the announcement. pyear is the year, pmonth is the month(from 1 to 12), pday is the day(from 1 to 31), phour is the hour(from 0 to 23), pminute is the minute(from 0 to 59), psecond is the second(from 0 to 59).


(lyear) (lmonth) (lday) (lhour) (lminute) (lsecond)
the last modified date. lyear is the year, lmonth is the month(from 1 to 12), lday is the day(from 1 to 31), lhour is the hour(from 0 to 23), lminute is the minute(from 0 to 59), lsecond is the second(from 0 to 59).


title
the title name of the announcement


text
the announcement's text
)

other functions
(
announcement_exists

this function returns the position of the announcement If exists.
double announcement_exists(string titlename)
parameters:
titlename
the name you wish to check If it is exists.

return value:
the position of the announcement title If it's exists on success, -1 on failure.

remarks:
this function returns the position index of the announcement title

example:
none


add

this function adds a specify announcement to the array.
void add_announcement(double py,double pm,double pd,double ph,double pmn,double ps,double ly,double lm,double ld,double lh,double lmn,double ls,string tt,string at,double per=-1)
parameters:
py
the published year.
pm
the published month.
pd
the published day.
ph
the published hour
pmn
the published minute.
ps
the published second.
ly
the last modified year.
lm
the last modified month.
ld
the last modified day.
lh
the last modified hour
lmn
the last modified minute.
ls
the last modified second.
tt
the title of the announcement.
at
the text of the announcement.
per
a specify position that announcement should be added. -1 means that the announcement will be added at last.

return value:
none

remarks:
this function adds a specify announcement to the announcements along with a title and the text.
when adding an announcement, be sure to have different titles. If the announcement with the title already exists it will be failed. though it isn't return you with the runtime errors, the announcement will not be added.

example:
none


remove_announcement

this function removes a specify announcement with the title.
void remove_announcement(string title_to_remove)
parameters:
title_to_remove
the title to be removed.

return value:
none

remarks:
this function removes announcement by specifying only the title name. be sure that the announcement you want to remove exists. otherwise, the announcement will not be able to remove since it isn't exist. you can load all the announcements using "load_announcements" function.

example:
none


save_announcements

this function saves all the announcements from the object.
void save_announcements()
parameters:
none

return value:
none

remarks:
this function saves all the announcements from the announcement object. you will need to use this function when your script ends, or collecting announcement to load once the next time runs. If, however, the array does not have any announcements, it won't be saved.

example:
none


) end of functions